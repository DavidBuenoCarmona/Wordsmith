# Jupiter Interlace SDK 1.0.0 · Complete English Developer Kit

This package includes the SDK and the complete integration materials.

## Start here

Open START-HERE.html for a contents navigator. Install Node.js 20.19+ and double-click Start-Demo.cmd, or run:

```sh
node scripts/serve.mjs
```

Open the example URL printed in the terminal. Examples are prebuilt and need no npm installation. To integrate the SDK into your own project, install the root TGZ file.

## Developer kit contents

| Content | Path | Purpose |
| --- | --- | --- |
| SDK builds | [dist/](dist/) | Modular SDK, standalone browser build, and core module |
| npm package | [jupiter-interlace-sdk-1.0.0.tgz](jupiter-interlace-sdk-1.0.0.tgz) | Install into a developer project |
| Type declarations | [dist/types/](dist/types/) | Complete TypeScript API signatures |
| GLB decoders | [dist/decoders/](dist/decoders/) | Draco and Basis/KTX2; Meshopt is integrated |
| Developer guide | [docs/developer-guide.html](docs/developer-guide.html) | HTML and Markdown integration guides |
| AI prompts | [docs/AI-PROMPTS.md](docs/AI-PROMPTS.md) | Six ready-to-use development prompts |
| Complete GLB example | [examples/glb-viewer/](examples/glb-viewer/) | File/URL loading, animation, calibration, fullscreen, patterns |
| Existing scene example | [examples/existing-scene/](examples/existing-scene/) | Integrate a standard Three.js scene |
| Atlas example | [examples/atlas/](examples/atlas/) | Integrate existing multi-view textures |
| All sample models | [examples/assets/](examples/assets/) | Ordinary, Draco, Meshopt, and KTX2 GLBs |
| Sample profile | [profiles/sample-profile.json](profiles/sample-profile.json) | Ready-to-import settings |
| Launch tools | [Start-Demo.cmd](Start-Demo.cmd) | Also includes the scripts/serve.mjs local server |
| Verification records | [verification/README.md](verification/README.md) | Complete results and machine-readable records |
| Interface previews | [preview/](preview/) | Guide, model, and mobile interface previews |
| License information | [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt) | Component notices and original license texts |

API identifiers, resource paths, Pitch/Tan/Offset, and original third-party licenses are preserved. Calibrate optical output on the target display.
