# Jupiter SDK · AI Development Prompts

See developer-guide.md and dist/types for the complete API and integration requirements.

## 11. AI development prompts

Provide the AI with the tarball, this guide, `dist/types`, your package.json, and relevant scene/render-loop files. Replace example paths, framework names, and calibration values with your own.

### Prompt A: Build a GLB viewer

```text
Build a GLB viewer using the supplied Jupiter Interlace SDK 1.0.0.
Read docs/developer-guide.md and dist/types/index.d.ts before coding.
Install ./jupiter-interlace-sdk-1.0.0.tgz and pin Three.js to 0.180.0.
Use JupiterViewer for URL and local GLB loading, progress, visible errors,
orbit/pan/zoom, camera fitting, animation play/pause, 2D/interlaced switching, and fullscreen.
Use createCalibrationPanel with pitch, tan, offset, order, subpixelOrder,
rotation, views, viewWidth, viewSpacing, and focusDistance.
Copy decoders to public/jupiter-decoders and configure both decoder paths.
Start in 2D. Treat unknown device calibration as pending, not verified.
Handle failed and superseded loads and component cleanup.
Do not add PLY/Spark or rewrite the interlacing equation.
Build the application and verify GLB loading, live settings, animation, and disposal in a browser.
Report changed files, run commands, test results, and remaining physical-display checks.
```

### Prompt B: Integrate an existing scene

```text
Integrate Jupiter Interlace SDK 1.0.0 into my existing Three.js scene.
Read the guide and types, then identify renderer, scene, PerspectiveCamera, and render loop.
Reuse these objects with InterlaceRenderer.render(scene, camera).
Update animation and physics once per displayed frame, never once per view.
Use sRGB output and a drawing buffer matching physical pixels.
Do not resize, blur, or apply FXAA after interlacing.
Keep the existing model loader. Add JSON calibration, 2D/interlaced switching,
view spacing, focus distance, and rendered-view controls.
If the project does not use Three.js 0.180.0, explain the compatibility work before changing it.
Do not mix two engine copies. Verify occlusion, camera preservation, temporal consistency,
saved settings, and resource ownership.
```

### Prompt C: Create a React or Vue component

```text
Wrap JupiterViewer in a reusable component matching my project's framework.
Read the real API first; do not invent loadModel or setPitch methods.
Accept a GLB URL, calibration, and render options as props; expose progress, load, and error events.
Create one viewer after mounting. Use loadGLB for URL changes and setters for parameter changes.
For React, use refs/effects and handle StrictMode; for Vue, use mounted/unmount lifecycle hooks.
Instantiate only on the client. Cancel pending work and dispose the viewer and panel on teardown.
Configure public decoder URLs. Verify one canvas per mount, rapid URL switching without stale models,
and no active render loop after unmounting.
```

### Prompt D: Integrate an atlas

```text
Use compositeAtlas to display my existing multi-view atlas.
Confirm texture dimensions, columns, rows, view count, Y direction, and color encoding from my code.
Cells are equal-sized, ordered left-to-right and bottom-to-top; views must be 1–30.
Set mode to interlaced and choose srgb or linear from the actual input.
Check texture.colorSpace to avoid duplicate exposure, tone mapping, or encoding.
Do not treat one ordinary image as 30 independently captured views.
Do not share texture objects across WebGL contexts.
Verify mapping with fixed-color views before connecting application textures.
```

### Prompt E: Build a calibration page

```text
Create a device-calibration page for Jupiter Interlace SDK.
Keep the v0.17.1 names and meaning: pitch, tan, offset.
Separate optical calibration from scene depth controls. Pitch is not lens spacing in millimeters.
Validate finite numbers, allow negative offsets, and support JSON import/export and named presets.
Explain that tan=0 selects the legacy center-view fallback, not a valid multi-view calibration.
Include 2D, single-view, and interlaced test patterns and show drawing-buffer dimensions and DPR.
Recheck the origin in fullscreen. Do not claim optical validation from an ordinary monitor screenshot.
Use supplied device values; leave unknown calibration pending.
```

### Prompt F: Diagnose integration or performance

```text
Diagnose my Jupiter Interlace SDK integration using the guide, console, and network evidence.
Identify whether the failure is downloading, parsing/decoding, single-view rendering, or interlacing.
Collect SDK/Three.js versions, WebGL extensions, model size, views, viewWidth,
physical output dimensions, getStats(), and the exact error. cpuMs is not GPU time or FPS.
If 2D works, check calibration, origin, DPR, color encoding, and post-processing.
If 2D fails, check model data, materials, lighting, camera, CORS, and decoder paths.
Reduce actual view count or per-view resolution for performance, but preserve final physical resolution.
Make the smallest justified fix, verify the affected flow, and identify remaining hardware checks.
```

Before accepting AI-generated integration, verify the real SDK API, decoder paths, local/remote GLB loading, error handling, live parameters, profile round trips, synchronized animation, and cleanup. Record browser tests separately from optical-display calibration.

