# Software Validation Record

Version 1.0.0. Validation covers TypeScript builds, 6 core algorithm tests, 72 GPU mapping configurations and 352,512 color-channel comparisons, 12 original-algorithm reference cases, ordinary/compressed GLB assets, animation, saved profiles, fullscreen output, and resource disposal.

Environment: Windows, Chrome 152, Three.js 0.180.0, WebGL2, NVIDIA GeForce RTX 5070.

Both language editions additionally verify example loading, Tan adjustment, profile export, compressed models, and document language. Optical calibration, crosstalk, and viewing range still require testing on the target display.
